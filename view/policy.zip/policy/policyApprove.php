<?php require_once __DIR__.'/../header.php';
require_once __DIR__.'/../../php/company/companyManager.php';
$manager=new CompanyManager();
$id=$manager->getCompanyIdForUser($_SESSION['user_id']);
$companyId=$id[0]['id'];
require_once __DIR__.'/../../php/policy/policyManager.php';
$GLOBALS['PolicyId'] = $_GET['PolicyId'];
$PolicyId = $_GET['PolicyId'];
$policyManager = new PolicyManager();
$policyData = $policyManager->getPolicyDetails($PolicyId);
$policyReview = $policyManager->getPolicyReviewer($PolicyId);
$policyApprove = $policyManager->getPolicyApprover($PolicyId);
$allUsers = $policyManager->getAllUsersForMail();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Fresh GRC Admin</title>
    <base href="/freshgrc/"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/jquery-ui-1.11.4/jquery-ui.js"></script>  
    <script type="text/javascript" src="assets/DataTables/Buttons-1.2.1/js/buttons.print.min.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/buttons/1.5.1/js/buttons.colVis.min.js"></script>  
    <script src="js/policy/policyManagement.js"></script>
    <link href="assets/img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
    <link href="assets/img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
    <link href="assets/img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
    <link href="assets/img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
    <link href="assets/img/favicon.png" rel="icon" type="image/png">
    <link href="assets/img/favicon.ico" rel="shortcut icon">
    <!-- metronic link for multiselect -->
    <link href="metronic/theme/assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="metronic/theme/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
    <link href="metronic/theme/assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="metronic/theme/assets/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="metronic/theme/assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
    <!-- end -->
    <!-- script link  multi select-->
    <script src="metronic/theme/assets/global/plugins/jquery.min.js" type="text/javascript"></script>
    <script src="metronic/theme/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="metronic/theme/assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
    <script src="metronic/theme/assets/global/scripts/app.min.js" type="text/javascript"></script>
    <script src="metronic/theme/assets/pages/scripts/components-select2.min.js" type="text/javascript"></script>
    <!-- end -->
    <link rel="stylesheet" href="assets/css/lib/font-awesome/font-awesome.min.css">  

    <style>      
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    height: 45px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
.portlet-body{
  background-color:#fff;
  padding:15px 155px;
}
    </style>
</head>
<body>   
     <?php 
        include '../siteHeader.php';
        $currentMenu = 'riskAdmin';
        include '../common/leftMenu.php';
        $userRole = $_SESSION['user_role'];
    ?>
</body>  
    <body >        
    <div class="page-content-wrapper"><!-- BEGIN CONTENT BODY -->
      <div class="page-content">        
        <div class="row">
          <div class="col-md-12">
            <div class="portlet box white">
              <div class="portlet-title">
                <div class="caption"><b>Policy Approval</b></div>                
              </div>
              <div class="portlet-body ">                    

                <div class="policy">
                  <table cellspacing="10">  
                   <tr>
                  <td style="background-color: #619ccc"><b>Policy Title :</b><?php echo $policyData[0]["Title"];?></td>
                  <td style="background-color: #619ccc"><b>Policy Type :</b><?php echo $policyData[0]["policyType"];?></td>
                  <td style="background-color: #619ccc"><b>Audience </b><?php echo $policyData[0]["audience"];?></td>
                </tr>
                <tr>
                  <td style="background-color: #bbc6d2"><b>Policy Classification :</b><?php echo $policyData[0]["policyClassification"];?> </td>
                  <td style="background-color: #bbc6d2"><b>Security Classification :</b><?php echo $policyData[0]["securityClassification"];?></td>
                  <td style="background-color: #bbc6d2"><b>Scope :</b><?php echo $policyData[0]["scope"];?></td>
                </tr>
                <tr>
                  <td style="background-color: #619ccc"><b>Purpose :</b><?php echo $policyData[0]["purpose"];?></td>
                  <td style="background-color: #619ccc"><b>Description :</b><?php echo $policyData[0]["description"];?></td>
                  <td style="background-color: #619ccc"><b>Owner :</b><?php echo $policyData[0]["owner"];?></td>
                </tr>
                <tr>
                  <td style="background-color: #bbc6d2"><b>Reviewers :</b><?php echo $policyReview[0]["reviewer"];?></td>
                  <td style="background-color: #bbc6d2"><b>Approvers :</b><?php echo $policyApprove[0]["approver"];?></td>
                  <td style="background-color: #bbc6d2"><b>Effective from :</b><?php echo $policyData[0]["effective_from"];?></td>
                </tr>
                <tr>
                  <td style="background-color: #619ccc"><b>Effective Till :</b><?php echo $policyData[0]["effective_till"];?> </td>
                  <td style="background-color: #619ccc"><b>Expected Publish Date : </b><?php echo $policyData[0]["expected_publish_date"];?></td>
                  <td style="background-color: #619ccc"><b>Review within Date :</b><?php echo $policyData[0]["review_within_date"];?></td>
                </tr>                           
                </table><br><br>                
                  <div class="row">
                    <div class="col-md-4" >
                      <div class="form-group">
                         <input type="hidden" class="form-control" id="loggedInUser" value="<?php echo $_SESSION['user_id'] ?>">
                        <input type="hidden" class="form-control" id="policyId">
                        <input type="hidden" class="form-control" id="action">
                        <input type="hidden" value="<?php echo $companyId?>" id="company">
                        <label for="notes"><b>Comment</b></label><br>
                        <textarea maxlength="5000" rows="1" class="form-control" id="comment"></textarea>
                      </div>       
                    </div>
                    <div class="col-md-4" >
                      <label for="sel1"><b>Status</b></label>
                      <select id="status" name="damagepotentialDropDown" class="form-control select2">
                        <option value=""></option>
                        <option value="1">Publish</option>                              
                        <option value="2">Reject</option>                              
                        <option value="4">Return</option>                              
                      </select>
                      <div style="min-height:20px;"></div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group" style="padding-top: 25px;">
                        <a data-toggle="collapse" data-target="#demo">
                        <i class="fa fa-share-alt-square" style="font-size:36px"></i>
                        </a> 
                      </div>  
                    </div>                                    
                  </div><br>
                  <div id="demo" class="collapse">
                    <div class="row">                                  
                    
                    <div class="col-md-4">
                      <div class="form-group">
                        <label for="multi-append" class="control-label"> Distribution List
                           </label>
                            <div class="input-group select2-bootstrap-append">
                              <select id="distributionuser" name="additionalStakeHolderDropDown"  class="form-control select2"  multiple>
                               <option></option>
                                <?php foreach($allUsers as $users){ ?>
                                  <option value="<?php echo $users['email']; ?>"><?php echo $users['last_name']; ?></option>
                                           <?php } ?>
                                       </select>

                              <span class="input-group-btn">
                                <button class="btn btn-default" type="button" data-select2-open="multi-append">
                                 <span class="glyphicon glyphicon-search"></span>
                                </button>
                              </span>
                            </div>
                      </div>
                    </div>                                            
                                   
                    <div class="col-md-4" >
                      <div class="form-group">
                        <label for="notes"><b>Subject</b></label><br>
                        <textarea maxlength="5000" rows="1" class="form-control" id="notes"></textarea>
                      </div>       
                    </div>
                    <div class="col-md-4" >
                      <div class="form-group">
                        <label for="notes"><b>Content</b></label><br>
                        <textarea maxlength="5000" rows="1" class="form-control" id="notes"></textarea>
                      </div>       
                    </div>
                  </div><br> 
                  <button type="button" id="manageButton" onclick="saveMailToUsers()" class="btn btn-primary" style="background-color:#4285f4">Send</button>                
                </div>
                <div class="row">
                <div class="col-md-12 text-center" >                                    
                  <button type="button" id="manageButton" onclick="savePublish(<?php echo $PolicyId;?>)" class="btn btn-primary" style="background-color:#4285f4">Submit</button>       
                </div>
                </div>                
                  </div>                               
              </div>
            </div>        
          </div>
        </div>
      </div>
    </div>           
</body>
