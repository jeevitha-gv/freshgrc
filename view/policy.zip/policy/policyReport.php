<?php 
require_once __DIR__.'/../header.php';
require_once __DIR__.'/../../php/policy/policyManager.php';
$GLOBALS['PolicyId'] = $_GET['PolicyId'];
$PolicyId = $_GET['PolicyId'];
$policyManager = new PolicyManager();
$policyData = $policyManager->getPolicyDetails($PolicyId);
$policyReview = $policyManager->getPolicyReviewer($PolicyId);
$policyApprove = $policyManager->getPolicyApprover($PolicyId);
$allUsers = $policyManager->getAllUsersForMail();
$policyControls = $policyManager->getPolicyControls($PolicyId);
?>

<!DOCTYPE html>
<html>

<head lang="en">
  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Fresh GRC Admin</title>
  <base href="/freshgrc/">

    <script src="js/policy/policyManagement.js"></script>
   <link rel="stylesheet" type="text/css" href="assets/DataTables/datatables.min.css" />
    <script type="text/javascript" src="assets/DataTables/datatables.min.js"></script>
    <script type="text/javascript" src="assets/jquery-ui-1.11.4/jquery-ui.js"></script>      
    <link rel="stylesheet" type="text/css" href="assets/jquery-ui-1.11.4/jquery-ui.css" />    
    


    <link href="assets/img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
    <link href="assets/img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
    <link href="assets/img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
    <link href="assets/img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
    <link href="assets/img/favicon.png" rel="icon" type="image/png">
    <link href="assets/img/favicon.ico" rel="shortcut icon">
    <!-- metronic link for multiselect -->
    <link href="metronic/theme/assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="metronic/theme/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <link href="metronic/theme/assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="metronic/theme/assets/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="metronic/theme/assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
    <!-- end -->
<!-- script link  multi select-->
     <script src="metronic/theme/assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="metronic/theme/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="metronic/theme/assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
        <script src="metronic/theme/assets/global/scripts/app.min.js" type="text/javascript"></script>
         <script src="metronic/theme/assets/pages/scripts/components-select2.min.js" type="text/javascript"></script>
         <!-- end -->

<script type="text/javascript" src="https://rawgit.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.min.js"></script>

    <link rel="stylesheet" href="assets/css/lib/font-awesome/font-awesome.min.css">
</head>
<style type="text/css">
  .page-sidebar.navbar-collapse {
    max-height: none!important;
    position: fixed;
}
.page-sidebar{
         margin-top: -1%;
      }
      .page-container {
    margin: 0;
    padding: 20px 20px 0;
    position: relative;
}
.btn{
  color: #fff;
  margin-bottom: 1%;
  background-color: #30c2d0;
  text-align:center;
}
</style>
<body  style="background-color: #f0f5f5">

  <body>
    <div>
    <button class="btn" id="cmd" data-toggle="tooltip" title="PDF" style="float:right;margin-right: 30px;"><span class="glyphicon glyphicon-file"></span></button> 
      <div class="container-fluid" style="margin-top: 30px;" id="element-to-print">        
        <div class="page-content-wrapper" >
          <div class="page-content" >
            <div class="col-md-12">
              <div class="portlet box green">
                <div class="portlet-title">
                  <div class="caption">Policy Report</div>
                  <div class="tools"> </div>
                </div>
                <div class="portlet-body">
                  <table class="table table-striped table-bordered table-hover dt-responsive" width="100%"  cellspacing="0" width="100%" id="sample_3">
                    <thead>
                      <tr>
                        <th>Policy Title</th>
                        <th>Policy Type</th>
                        <th>Security Classification</th>
                        <th>Policy Classification</th>
                        <th>Audience</th>
                      </tr>
                    </thead>
                    <tbody>                  
                      <tr>
                        <td><?php echo $policyData[0]["Title"];?></td>
                        <td><?php echo $policyData[0]["policyType"];?></td>
                        <td><?php echo $policyData[0]["securityClassification"];?></td>
                        <td><?php echo $policyData[0]["policyClassification"];?></td>
                        <td><?php echo $policyData[0]["audience"];?></td>
                        </tr>      
                    </tbody>
                  </table>
                  <table class="table table-striped table-bordered table-hover dt-responsive" width="100%"  cellspacing="0" width="100%" id="sample_3">
                  <thead>
                  <tr>
                    <th>Scope</th>
                    <th>Purpose</th>
                    <th>Description</th>                        
                  </tr>
                  <thead>
                  <tbody>
                    <tr>
                      <td><?php echo $policyData[0]["scope"];?></td>
                      <td><?php echo $policyData[0]["purpose"];?></td>
                      <td><?php echo $policyData[0]["description"];?></td>                           
                    </tr>      
                  </tbody>
                  </table>
                    
                  <table class="table table-striped table-bordered table-hover dt-responsive" width="100%"  cellspacing="0" width="100%" id="sample_3">
                    
                    <thead>
                      <tr>
                        <th>Owner</th>
                        <th>Reviewer</th>
                        <th>Effective from</th>
                        <th>Effective Till</th>
                        <th>Expected Publish Date</th>
                        <th>Review within Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><?php echo $policyData[0]["owner"];?></td> 
                        <td><?php echo $policyReview[0]["reviewer"];?></td>             
                        <td><?php echo $policyData[0]["effective_from"];?></td>  
                        <td><?php echo $policyData[0]["effective_till"];?> </td> 
                        <td><?php echo $policyData[0]["expected_publish_date"];?></td> 
                        <td><?php echo $policyData[0]["review_within_date"];?></td>             
                      </tr>
                    </tbody>
                  </table>
                  <div class="page-header"><h5><strong>Statements:</strong></h5></div>
                 <?php
                foreach ($policyControls as $key => $control) {
                ?> 
                     <div class="panel panel-default">
                        <div style="background-color: #f5f5f5;font-weight:400;font-size:14px;color:#333" class="panel-heading"><strong>Statement:<?php echo $control['statement'];?></strong></div>
                            
                               <table class="table table-striped table-bordered table-hover dt-responsive" width="100%"  cellspacing="0" width="100%" id="sample_3">
                  <thead>
                  <tr>
                    <th>Main Heading</th>
                    <th>Sub Heading</th>
                    <th>Description</th>                        
                  </tr>
                  <thead>
                  <tbody>
                    <tr>
                      <td><?php echo $control["main_heading"];?></td>
                      <td><?php echo $control["sub_heading"];?></td>
                      <td><?php echo $control["description"];?></td>                           
                    </tr>      
                  </tbody>
                  </table>                             
                      </div>
                    <?php
                    }
                    ?>
                <button class="btn" style="margin:auto;display:block" onclick="goToPreviousPage()">Back</button>
                </div>
              </div>         
            </div>                            
          </div>
        </div>
      </div>       
      </div>
    </div> 
    <script type="text/javascript">
$('#cmd').click(function() {
var element = document.getElementById('element-to-print');
html2pdf(element, {
  margin:       0,
  filename:     'PolicyReport.pdf',
  image:        { type: 'jpeg', quality: 0.98 },
  html2canvas:  { dpi: 192, letterRendering: true },
  jsPDF:        { unit: 'in', format: 'a3', orientation: 'portrait' }
});
});
</script>  
  </body>
</html>

